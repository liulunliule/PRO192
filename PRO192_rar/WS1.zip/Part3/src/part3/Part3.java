/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part3;

/**
 *
 * @author ADMIN
 */
import java.util.Scanner;
public class Part3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        String[] list = new String[10];
        for (int i = 0; i < 10; i++){
            Scanner sc = new Scanner(System.in);
            System.out.println("Please enter the student " + (i+1) + " : ");
            list[i] = sc.nextLine();
        }
        
        for (int i = 0; i < 10; i++)
            System.out.println("Ten hoc sinh thu " + i + " la " + list[i].toUpperCase());
    }
}
