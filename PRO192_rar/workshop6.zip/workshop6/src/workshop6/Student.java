
package workshop6;
import java.util.Scanner;
/**
 *
 * @author DELL
 */
public class Student {
    
    private String code, name;
    private int mark;
    private String parttern = "^S//d{3}";
    
    public Student(){  
    }
    
    
    public Student(String code, String name, int mark) {
        this.code = code;
        this.mark = mark;
        this.name = name;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        if(code.matches(parttern))
            this.code = code;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        if (mark >= 0 && mark <= 10)
            this.mark = mark;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != "")
            this.name = name;
    }
    
    public void inputStudent(){
        
        Scanner sc = new Scanner(System.in);
        
        
            System.out.print("Enter student code: ");
            setCode(sc.nextLine());            
            
            System.out.print("Enter student name: ");
            setName(sc.nextLine());
            
            System.out.print("Enter student mark: ");
            setMark(sc.nextInt());
            
    }
    
}
