package workshop6;

public class main{
    
    public static void main(String[] args){
        
        Student n = new Student();
        n.inputStudent();
        
        System.out.println(n.getCode());
        System.out.println(n.getName());
        System.out.println(n.getMark());
    }
}
