/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lap01oopthuylieu;

/**
 *
 * @author 840G3
 */
public class Product {
       protected String name;
    protected double price;

    public Product() {
    }

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getImportTax() {
        return (this.price + (this.price * 0.1));
    }
    
    public void showInfo(){
        System.out.printf("|name:%-4s|price:%4.1f|product with tax: %4.1f|\n", name, price, getImportTax());
    }
}

