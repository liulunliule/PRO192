/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lap01oopthuylieu;
import java.util.Scanner;
    import java.util.ArrayList;
/**
 *
 * @author 840G3
 */
public class Main {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        Scanner sc3 = new Scanner(System.in);
        ArrayList<Product> pList = new ArrayList();
        int sl;
        System.out.print("How many product you want? ");
        sl = sc.nextInt();
        for (int i = 0; i < sl; i++) {
            int count = i + 1;
            System.out.println("Product " + count);
            System.out.print("Product name: ");
            String name = sc1.nextLine();
            System.out.print("Product price: ");
            double price = sc2.nextDouble();
            System.out.println("Do you want tax this? \n 1.Yes  2.No ");
            int checkTax = sc3.nextInt();
            switch (checkTax) {
                case 1:
                    Product p = new Product(name, price);
                    pList.add(p);
                    break;
                case 2:
                    Product ntp = new NoTaxProduct(name, price);
                    pList.add(ntp);
                    break;
                default:
                    System.out.println("Your choose incorrect, the product will be taxed");
                    break;
            }
        }
        for (Product p : pList) {
            p.showInfo();

        }
    }
    }